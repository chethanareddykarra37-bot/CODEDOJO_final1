(() => {
  "use strict";

  const API_BASE = "http://localhost:3000/api";

  class EventBus {
    constructor() {
      this.listeners = new Map();
    }
    on(event, fn) {
      if (!this.listeners.has(event)) this.listeners.set(event, new Set());
      this.listeners.get(event).add(fn);
      return () => this.listeners.get(event)?.delete(fn);
    }
    emit(event, payload) {
      const set = this.listeners.get(event);
      if (!set) return;
      for (const fn of set) fn(payload);
    }
  }

  function sanitizeText(input, maxLen = 120) {
    return String(input ?? "")
      .replace(/[<>&"'`]/g, "")
      .trim()
      .slice(0, maxLen);
  }

  function levenshteinDistance(a, b) {
    const s1 = a.trim();
    const s2 = b.trim();
    const m = s1.length;
    const n = s2.length;
    if (m === 0) return n;
    if (n === 0) return m;
    const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        const cost = s1[i - 1] === s2[j - 1] ? 0 : 1;
        dp[i][j] = Math.min(
          dp[i - 1][j] + 1,
          dp[i][j - 1] + 1,
          dp[i - 1][j - 1] + cost
        );
      }
    }
    return dp[m][n];
  }

  function similarityRatio(a, b) {
    const maxLen = Math.max(a.length, b.length);
    if (maxLen === 0) return 100;
    const dist = levenshteinDistance(a, b);
    return Math.round(((maxLen - dist) / maxLen) * 100);
  }

  const DEFAULT_PROBLEMS = [
    {
      id: "p1",
      title: "Two Sum Variant",
      difficulty: "Easy",
      tags: ["Arrays", "Hash Maps"],
      points: 100,
      statement: "Given an array of integers and a target sum, return true if any two distinct elements add up to target.",
      sampleInput: "[2, 7, 11, 15], target = 9",
      sampleOutput: "true",
      hint: "Think about storing complements in a Set or Map as you scan once through the array.",
      starterCode: "function solve(nums, target) {\n  const seen = new Set();\n  for (const n of nums) {\n    if (seen.has(target - n)) return true;\n    seen.add(n);\n  }\n  return false;\n}",
      tests: [
        { args: [[2, 7, 11, 15], 9], expected: true },
        { args: [[3, 2, 4], 6], expected: true },
        { args: [[1, 2, 3], 10], expected: false },
        { args: [[-5, 10, 3], 5], expected: true }
      ]
    },
    {
      id: "p2",
      title: "Valid Palindrome Stream",
      difficulty: "Easy",
      tags: ["Two Pointers", "Strings"],
      points: 120,
      statement: "Return true if the alphanumeric characters of s form a palindrome (case-insensitive).",
      sampleInput: '"A man, a plan, a canal: Panama"',
      sampleOutput: "true",
      hint: "Use two pointers from start and end, skipping non-alphanumeric characters.",
      starterCode: "function solve(s) {\n  const clean = String(s).toLowerCase().replace(/[^a-z0-9]/g, '');\n  let l = 0, r = clean.length - 1;\n  while (l < r) {\n    if (clean[l++] !== clean[r--]) return false;\n  }\n  return true;\n}",
      tests: [
        { args: ["A man, a plan, a canal: Panama"], expected: true },
        { args: ["race a car"], expected: false },
        { args: [""], expected: true }
      ]
    },
    {
      id: "p3",
      title: "Max Subarray Sprint",
      difficulty: "Medium",
      tags: ["Arrays", "Dynamic Programming"],
      points: 180,
      statement: "Find the maximum sum of a contiguous non-empty subarray.",
      sampleInput: "[-2, 1, -3, 4, -1, 2, 1, -5, 4]",
      sampleOutput: "6",
      hint: "At each element, decide whether to extend the current subarray or start fresh at the current value.",
      starterCode: "function solve(nums) {\n  let cur = nums[0], best = nums[0];\n  for (let i = 1; i < nums.length; i++) {\n    cur = Math.max(nums[i], cur + nums[i]);\n    best = Math.max(best, cur);\n  }\n  return best;\n}",
      tests: [
        { args: [[-2, 1, -3, 4, -1, 2, 1, -5, 4]], expected: 6 },
        { args: [[5]], expected: 5 },
        { args: [[-4, -2, -9]], expected: -2 }
      ]
    }
  ];

  const bus = new EventBus();

  const state = {
    user: null, // { handle, token }
    problems: DEFAULT_PROBLEMS,
    selectedProblemId: "p1",
    streak: 3,
    solvedIds: [],
    failCount: 0,
    activityDays: [0, 1, 2, 1, 3, 2, 4, 1, 2, 0, 3, 4, 2, 1],
    squads: [
      {
        name: "Binary Beasts",
        accessCode: "DOJO2026",
        members: ["aarav_cs", "diya_dev", "rohan_algo"],
        solves: 4,
        streakBonus: 60,
        score: 460,
        lastSnippet: "function solve(nums, target) { return true; }"
      },
      {
        name: "Stack Overflowers",
        accessCode: "STACK99",
        members: ["meera_py", "kabir_ts"],
        solves: 3,
        streakBonus: 40,
        score: 340,
        lastSnippet: "function solve(nums, target) { return false; }"
      }
    ],
    activeSquadName: "Binary Beasts",
    sprintSeconds: 3600,
    sprintRunning: false
  };

  async function apiFetch(endpoint, options = {}) {
    try {
      const headers = { "Content-Type": "application/json", ...options.headers };
      if (state.user && state.user.token) {
        headers["Authorization"] = `Bearer ${state.user.token}`;
      }
      const res = await fetch(`${API_BASE}${endpoint}`, { ...options, headers });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: res.statusText }));
        throw new Error(err.error || "Server error");
      }
      return await res.json();
    } catch (e) {
      console.warn(`Backend API ${endpoint} unavailable, falling back to LocalStorage/State:`, e.message);
      return null;
    }
  }

  function saveStateToLocal() {
    try {
      localStorage.setItem("codedojo_state", JSON.stringify({
        user: state.user,
        streak: state.streak,
        solvedIds: state.solvedIds,
        failCount: state.failCount,
        activityDays: state.activityDays,
        squads: state.squads,
        activeSquadName: state.activeSquadName
      }));
    } catch (e) {
      console.error("LocalStorage save error", e);
    }
  }

  function loadStateFromLocal() {
    try {
      const saved = localStorage.getItem("codedojo_state");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.user) state.user = parsed.user;
        if (Array.isArray(parsed.solvedIds)) state.solvedIds = parsed.solvedIds;
        if (typeof parsed.streak === "number") state.streak = parsed.streak;
        if (typeof parsed.failCount === "number") state.failCount = parsed.failCount;
        if (Array.isArray(parsed.activityDays)) state.activityDays = parsed.activityDays;
        if (Array.isArray(parsed.squads) && parsed.squads.length > 0) state.squads = parsed.squads;
        if (parsed.activeSquadName) state.activeSquadName = parsed.activeSquadName;
      }
    } catch (e) {
      console.error("LocalStorage load error", e);
    }
  }

  async function syncFromBackend() {
    loadStateFromLocal();
    const remoteData = await apiFetch("/sync");
    if (remoteData) {
      if (remoteData.squads) state.squads = remoteData.squads;
      if (remoteData.problems) state.problems = remoteData.problems;
    }
    if (state.user && state.user.token) {
      const me = await apiFetch("/auth/me");
      if (me && me.user) {
        state.streak = me.user.streak;
        state.solvedIds = me.user.solvedIds;
        state.failCount = me.user.failCount;
        state.activityDays = me.user.activityDays;
      }
    }
    saveStateToLocal();
    renderAll();
  }

  function runInWorker(code, tests, timeoutMs = 600) {
    return new Promise((resolve) => {
      const workerBlob = new Blob([`
        self.onmessage = function(e) {
          const { code, tests } = e.data;
          try {
            const fn = new Function('"use strict"; ' + code + '\nif (typeof solve !== "function") throw new Error("Define function solve(...)"); return solve;');
            const solveFn = fn();
            const results = tests.map((t, idx) => {
              const actual = solveFn(...JSON.parse(JSON.stringify(t.args)));
              const passed = JSON.stringify(actual) === JSON.stringify(t.expected);
              return { index: idx + 1, passed, actual, expected: t.expected };
            });
            self.postMessage({ status: "OK", results });
          } catch (err) {
            self.postMessage({ status: "ERR", error: err && err.message ? err.message : "Runtime Error" });
          }
        };
      `], { type: "application/javascript" });

      const url = URL.createObjectURL(workerBlob);
      const worker = new Worker(url);
      let settled = false;

      const timer = setTimeout(() => {
        if (!settled) {
          settled = true;
          worker.terminate();
          URL.revokeObjectURL(url);
          resolve({ status: "TLE", error: "Time Limit Exceeded (>600ms)" });
        }
      }, timeoutMs);

      worker.onmessage = (ev) => {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          worker.terminate();
          URL.revokeObjectURL(url);
          resolve(ev.data);
        }
      };

      worker.onerror = () => {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          worker.terminate();
          URL.revokeObjectURL(url);
          resolve({ status: "ERR", error: "Sandbox execution error" });
        }
      };

      worker.postMessage({ code, tests });
    });
  }

  function renderAll() {
    document.getElementById("streakCount").textContent = `${state.streak} days`;
    document.getElementById("solvedCount").textContent = `${state.solvedIds.length}`;
    document.getElementById("failCount").textContent = `${state.failCount}`;

    const mins = String(Math.floor(state.sprintSeconds / 60)).padStart(2, "0");
    const secs = String(state.sprintSeconds % 60).padStart(2, "0");
    document.getElementById("sprintTimer").textContent = `${mins}:${secs}`;

    const badge = document.getElementById("sessionBadge");
    const loginBtn = document.getElementById("loginBtn");
    const logoutBtn = document.getElementById("logoutBtn");
    const usernameInput = document.getElementById("usernameInput");
    const passcodeInput = document.getElementById("passcodeInput");

    if (state.user) {
      badge.textContent = `Signed in: @${state.user.handle}`;
      badge.classList.remove("hidden");
      loginBtn.classList.add("hidden");
      logoutBtn.classList.remove("hidden");
      usernameInput.classList.add("hidden");
      passcodeInput.classList.add("hidden");
    } else {
      badge.classList.add("hidden");
      loginBtn.classList.remove("hidden");
      logoutBtn.classList.add("hidden");
      usernameInput.classList.remove("hidden");
      passcodeInput.classList.remove("hidden");
    }

    const prob = state.problems.find((p) => p.id === state.selectedProblemId) || state.problems[0];
    if (prob) {
      document.getElementById("problemDetails").innerHTML = `
        <div><strong>${sanitizeText(prob.title)}</strong> <span class="badge">${sanitizeText(prob.difficulty)} • ${prob.points} pts</span></div>
        <p>${sanitizeText(prob.statement, 300)}</p>
        <p><strong>Sample:</strong> <code>${sanitizeText(prob.sampleInput)}</code> → <code>${sanitizeText(prob.sampleOutput)}</code></p>
        <p><strong>Tags:</strong> ${prob.tags.map((t) => sanitizeText(t)).join(", ")}</p>
      `;
    }

    const hintBox = document.getElementById("hintBox");
    if (state.failCount >= 3 && prob) {
      hintBox.textContent = `AI Hint (unlocked after 3 failed runs): ${prob.hint}`;
      hintBox.classList.remove("hidden");
    } else {
      hintBox.classList.add("hidden");
    }

    const activeSquad = state.squads.find((s) => s.name === state.activeSquadName) || state.squads[0];
    if (activeSquad) {
      document.getElementById("squadDisplay").innerHTML = `
        <div><strong>Squad:</strong> ${sanitizeText(activeSquad.name)} <span class="badge">Code: ${sanitizeText(activeSquad.accessCode)}</span></div>
        <div><strong>Members (${activeSquad.members.length}/4):</strong> ${activeSquad.members.map((m) => sanitizeText(m)).join(", ")}</div>
      `;
    }

    const sorted = [...state.squads].sort((a, b) => b.score - a.score);
    document.getElementById("leaderboardBody").innerHTML = sorted
      .map(
        (sq, idx) => `
      <tr>
        <td>#${idx + 1}</td>
        <td>${sanitizeText(sq.name)}</td>
        <td>${sq.solves}</td>
        <td>+${sq.streakBonus}</td>
        <td><strong>${sq.score}</strong></td>
      </tr>
    `
      )
      .join("");

    const heatmap = document.getElementById("heatmapGrid");
    heatmap.innerHTML = state.activityDays
      .map((lvl) => `<div class="heat-cell heat-${Math.min(4, Math.max(0, lvl))}" title="Activity level ${lvl}"></div>`)
      .join("");
  }

  function populateProblemSelect() {
    const tag = document.getElementById("tagFilter").value;
    const diff = document.getElementById("diffFilter").value;
    const filtered = state.problems.filter((p) => {
      const tagOk = tag === "ALL" || p.tags.includes(tag);
      const diffOk = diff === "ALL" || p.difficulty === diff;
      return tagOk && diffOk;
    });
    const list = filtered.length ? filtered : state.problems;
    const sel = document.getElementById("problemSelect");
    sel.innerHTML = list.map((p) => `<option value="${p.id}">${sanitizeText(p.title)} (${p.difficulty})</option>`).join("");
    if (!list.some((p) => p.id === state.selectedProblemId)) {
      state.selectedProblemId = list[0].id;
    }
    sel.value = state.selectedProblemId;
    const prob = state.problems.find((p) => p.id === state.selectedProblemId);
    if (prob) document.getElementById("codeEditor").value = prob.starterCode;
  }

  document.getElementById("loginBtn").addEventListener("click", async () => {
    const handle = sanitizeText(document.getElementById("usernameInput").value, 24);
    const password = document.getElementById("passcodeInput").value || "";
    if (!/^[a-zA-Z0-9_-]{3,24}$/.test(handle) || password.length < 4) {
      alert("Enter a valid handle (3-24 alphanumeric/_/- chars) and a 4+ character password.");
      return;
    }

    const res = await apiFetch("/auth/login", {
      method: "POST",
      body: JSON.stringify({ handle, password })
    });

    if (res && res.token) {
      state.user = { handle: res.user.handle, token: res.token };
      state.streak = res.user.streak;
      state.solvedIds = res.user.solvedIds;
      state.failCount = res.user.failCount;
      state.activityDays = res.user.activityDays;
    } else {
      state.user = { handle, token: "local_session_token" };
    }

    document.getElementById("passcodeInput").value = "";
    saveStateToLocal();
    bus.emit("auth:changed", state.user);
  });

  document.getElementById("logoutBtn").addEventListener("click", () => {
    state.user = null;
    saveStateToLocal();
    renderAll();
  });

  document.getElementById("tagFilter").addEventListener("change", () => {
    populateProblemSelect();
    renderAll();
  });

  document.getElementById("diffFilter").addEventListener("change", () => {
    populateProblemSelect();
    renderAll();
  });

  document.getElementById("problemSelect").addEventListener("change", (e) => {
    state.selectedProblemId = e.target.value;
    const prob = state.problems.find((p) => p.id === state.selectedProblemId);
    if (prob) document.getElementById("codeEditor").value = prob.starterCode;
    document.getElementById("testResults").textContent = "";
    renderAll();
  });

  document.getElementById("runTestsBtn").addEventListener("click", async () => {
    const lang = document.getElementById("langSelect").value;
    const code = document.getElementById("codeEditor").value;
    const prob = state.problems.find((p) => p.id === state.selectedProblemId);
    const out = document.getElementById("testResults");

    if (lang === "python") {
      const hasDef = /def\s+solve\s*\(/.test(code);
      out.textContent = hasDef
        ? "Python syntax check passed (def solve found). Switch to JavaScript mode for live sandboxed test assertions."
        : "Python check failed: expected 'def solve(...)' function definition.";
      return;
    }

    const res = await runInWorker(code, prob.tests);
    if (res.status !== "OK") {
      state.failCount += 1;
      out.textContent = `${res.status}: ${res.error}`;
      saveStateToLocal();
      renderAll();
      return;
    }

    const allPassed = res.results.every((r) => r.passed);
    if (!allPassed) state.failCount += 1;
    out.innerHTML = res.results
      .map((r) => `<div>Test #${r.index}: <strong>${r.passed ? "Accepted" : "Wrong Answer"}</strong> (got ${JSON.stringify(r.actual)}, expected ${JSON.stringify(r.expected)})</div>`)
      .join("");
    saveStateToLocal();
    renderAll();
  });

  document.getElementById("submitSolBtn").addEventListener("click", async () => {
    if (!state.user) {
      alert("Please sign in with your handle and password before submitting.");
      return;
    }
    const code = document.getElementById("codeEditor").value;
    const prob = state.problems.find((p) => p.id === state.selectedProblemId);
    const res = await runInWorker(code, prob.tests);
    const out = document.getElementById("testResults");

    if (res.status !== "OK" || !res.results.every((r) => r.passed)) {
      state.failCount += 1;
      out.textContent = "Submission rejected: not all test cases passed.";
      saveStateToLocal();
      renderAll();
      return;
    }

    const activeSquad = state.squads.find((s) => s.name === state.activeSquadName) || state.squads[0];
    activeSquad.lastSnippet = code;

    if (state.solvedIds.includes(prob.id)) {
      out.textContent = `Already solved "${prob.title}". Duplicate points prevented.`;
      saveStateToLocal();
      renderAll();
      return;
    }

    state.solvedIds.push(prob.id);
    const multiplier = state.sprintRunning ? 1.5 : 1;
    const earned = Math.round(prob.points * multiplier);
    activeSquad.solves += 1;
    activeSquad.score += earned;
    state.activityDays[state.activityDays.length - 1] = Math.min(4, state.activityDays[state.activityDays.length - 1] + 2);

    await apiFetch("/submissions", {
      method: "POST",
      body: JSON.stringify({
        problemId: prob.id,
        code,
        squadName: activeSquad.name,
        passed: true,
        points: earned
      })
    });

    out.textContent = `Accepted! +${earned} pts awarded to ${activeSquad.name}.`;
    saveStateToLocal();
    renderAll();
  });

  document.getElementById("squadForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = sanitizeText(document.getElementById("squadNameInput").value, 32);
    const code = sanitizeText(document.getElementById("squadCodeInput").value, 8).toUpperCase();
    if (!name || !/^[A-Z0-9]{4,8}$/.test(code)) {
      alert("Provide a squad name and a 4-8 character alphanumeric Team Access Code.");
      return;
    }

    const serverRes = await apiFetch("/squads", {
      method: "POST",
      body: JSON.stringify({ name, accessCode: code })
    });

    if (serverRes && serverRes.squads) {
      state.squads = serverRes.squads;
      state.activeSquadName = name;
    } else {
      let existing = state.squads.find((s) => s.name.toLowerCase() === name.toLowerCase());
      if (existing) {
        if (existing.accessCode !== code) {
          alert("Invalid Team Access Code for this squad.");
          return;
        }
        if (state.user && !existing.members.includes(state.user.handle) && existing.members.length < 4) {
          existing.members.push(state.user.handle);
        }
        state.activeSquadName = existing.name;
      } else {
        const members = state.user ? [state.user.handle] : ["captain_1"];
        state.squads.push({
          name,
          accessCode: code,
          members,
          solves: 0,
          streakBonus: 20,
          score: 20,
          lastSnippet: ""
        });
        state.activeSquadName = name;
      }
    }
    saveStateToLocal();
    renderAll();
  });

  document.getElementById("addMemberBtn").addEventListener("click", () => {
    const handle = sanitizeText(document.getElementById("memberInput").value, 24);
    if (!/^[a-zA-Z0-9_-]{3,24}$/.test(handle)) {
      alert("Enter a valid member handle (3-24 chars).");
      return;
    }
    const activeSquad = state.squads.find((s) => s.name === state.activeSquadName) || state.squads[0];
    if (activeSquad.members.length >= 4) {
      alert("Squad roster is full (max 4 members).");
      return;
    }
    if (!activeSquad.members.includes(handle)) {
      activeSquad.members.push(handle);
    }
    document.getElementById("memberInput").value = "";
    saveStateToLocal();
    renderAll();
  });

  document.getElementById("toggleSprintBtn").addEventListener("click", () => {
    state.sprintRunning = !state.sprintRunning;
    renderAll();
  });

  setInterval(() => {
    if (state.sprintRunning && state.sprintSeconds > 0) {
      state.sprintSeconds -= 1;
      renderAll();
    }
  }, 1000);

  document.getElementById("checkPlagBtn").addEventListener("click", () => {
    const snippets = state.squads.filter((s) => s.lastSnippet);
    if (snippets.length < 2) {
      document.getElementById("plagiarismOutput").textContent = "Need at least 2 team submissions to compare similarity.";
      return;
    }
    const pairs = [];
    for (let i = 0; i < snippets.length; i++) {
      for (let j = i + 1; j < snippets.length; j++) {
        const sim = similarityRatio(snippets[i].lastSnippet, snippets[j].lastSnippet);
        pairs.push(`${snippets[i].name} vs ${snippets[j].name}: ${sim}% similarity`);
      }
    }
    document.getElementById("plagiarismOutput").textContent = pairs.join(" | ");
  });

  bus.on("auth:changed", renderAll);

  syncFromBackend().then(() => {
    populateProblemSelect();
    renderAll();
  });
})();
