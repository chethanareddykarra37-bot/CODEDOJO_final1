const assert = require("assert");
const bcrypt = require("bcryptjs");
const { app, db } = require("../backend/server");

console.log("==========================================");
console.log("   CODEDOJO AUTOMATED TEST SUITE        ");
console.log("==========================================");

function evalTwoSumVariant(nums, target) {
  const seen = new Set();
  for (const n of nums) {
    if (seen.has(target - n)) return true;
    seen.add(n);
  }
  return false;
}

function evalValidPalindrome(s) {
  const clean = String(s).toLowerCase().replace(/[^a-z0-9]/g, '');
  let l = 0, r = clean.length - 1;
  while (l < r) {
    if (clean[l++] !== clean[r--]) return false;
  }
  return true;
}

function evalMaxSubarray(nums) {
  let cur = nums[0], best = nums[0];
  for (let i = 1; i < nums.length; i++) {
    cur = Math.max(nums[i], cur + nums[i]);
    best = Math.max(best, cur);
  }
  return best;
}

assert.strictEqual(evalTwoSumVariant([2, 7, 11, 15], 9), true, "TwoSum: [2,7,11,15], target=9 failed");
assert.strictEqual(evalTwoSumVariant([3, 2, 4], 6), true, "TwoSum: [3,2,4], target=6 failed");
assert.strictEqual(evalTwoSumVariant([1, 2, 3], 10), false, "TwoSum: [1,2,3], target=10 failed");
console.log("✔ Problem Evaluation 1 (Two Sum Variant): PASSED");

assert.strictEqual(evalValidPalindrome("A man, a plan, a canal: Panama"), true, "Palindrome: Valid sentence failed");
assert.strictEqual(evalValidPalindrome("race a car"), false, "Palindrome: Invalid sentence failed");
console.log("✔ Problem Evaluation 2 (Valid Palindrome Stream): PASSED");

assert.strictEqual(evalMaxSubarray([-2, 1, -3, 4, -1, 2, 1, -5, 4]), 6, "MaxSubarray: Mixed array failed");
assert.strictEqual(evalMaxSubarray([-4, -2, -9]), -2, "MaxSubarray: All negative array failed");
console.log("✔ Problem Evaluation 3 (Max Subarray Sprint): PASSED");

function levenshtein(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
    }
  }
  return dp[m][n];
}

assert.strictEqual(levenshtein("kitten", "sitting"), 3);
assert.strictEqual(levenshtein("solve", "solve"), 0);
console.log("✔ Levenshtein Plagiarism Audit Algorithm: PASSED");

async function testBcryptAuth() {
  const password = "SuperSecretPassword123!";
  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash(password, salt);

  assert.notStrictEqual(password, hash, "Password must not equal plaintext hash");
  const isMatch = await bcrypt.compare(password, hash);
  const isWrong = await bcrypt.compare("WrongPassword", hash);

  assert.strictEqual(isMatch, true, "Valid bcrypt comparison failed");
  assert.strictEqual(isWrong, false, "Invalid bcrypt comparison failed");
  console.log("✔ Bcrypt Password Hashing & Verification: PASSED");
}

testBcryptAuth().then(() => {
  console.log("==========================================");
  console.log("  ALL TESTS PASSED SUCCESSFULLY (100%)    ");
  console.log("==========================================");
}).catch((err) => {
  console.error("❌ Test failed:", err);
  process.exit(1);
});
