const express = require("express");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");

const app = express();
app.use(express.json({ limit: "64kb" }));

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  if (req.method === "OPTIONS") return res.sendStatus(200);
  next();
});

const db = {
  users: new Map(),
  squads: [
    {
      name: "Binary Beasts",
      accessCode: "DOJO2026",
      members: ["aarav_cs", "diya_dev", "rohan_algo"],
      solves: 4,
      streakBonus: 60,
      score: 460,
      lastSnippet: "function solve(nums, target) { return true; }"
    },
    {
      name: "Stack Overflowers",
      accessCode: "STACK99",
      members: ["meera_py", "kabir_ts"],
      solves: 3,
      streakBonus: 40,
      score: 340,
      lastSnippet: "function solve(nums, target) { return false; }"
    }
  ],
  submissions: []
};

const sessions = new Map();

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or invalid authorization token" });
  }
  const token = authHeader.split(" ")[1];
  const handle = sessions.get(token);
  if (!handle || !db.users.has(handle)) {
    return res.status(401).json({ error: "Session expired or invalid" });
  }
  req.user = db.users.get(handle);
  next();
}

app.post("/api/auth/login", async (req, res) => {
  try {
    const handle = String(req.body?.handle || "").trim();
    const password = String(req.body?.password || "");

    if (!/^[a-zA-Z0-9_-]{3,24}$/.test(handle) || password.length < 4) {
      return res.status(400).json({ error: "Handle must be 3-24 alphanumeric chars and password 4+ chars." });
    }

    let user = db.users.get(handle);
    if (!user) {
      const salt = await bcrypt.genSalt(10);
      const passwordHash = await bcrypt.hash(password, salt);
      user = {
        handle,
        passwordHash,
        streak: 1,
        solvedIds: [],
        failCount: 0,
        activityDays: [0, 0, 1, 1, 2, 1, 2, 1, 3, 2, 4]
      };
      db.users.set(handle, user);
    } else {
      const isMatch = await bcrypt.compare(password, user.passwordHash);
      if (!isMatch) {
        return res.status(401).json({ error: "Invalid password credentials." });
      }
    }

    const token = crypto.randomBytes(24).toString("hex");
    sessions.set(token, user.handle);

    const { passwordHash, ...userClean } = user;
    return res.json({ token, user: userClean });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

app.get("/api/auth/me", authMiddleware, (req, res) => {
  const { passwordHash, ...userClean } = req.user;
  res.json({ user: userClean });
});

app.get("/api/sync", (req, res) => {
  res.json({
    squads: db.squads
  });
});

app.post("/api/squads", (req, res) => {
  const name = String(req.body?.name || "").trim();
  const accessCode = String(req.body?.accessCode || "").trim().toUpperCase();

  if (!name || !/^[A-Z0-9]{4,8}$/.test(accessCode)) {
    return res.status(400).json({ error: "Invalid squad name or access code format." });
  }

  let squad = db.squads.find((s) => s.name.toLowerCase() === name.toLowerCase());
  if (squad) {
    if (squad.accessCode !== accessCode) {
      return res.status(403).json({ error: "Incorrect Team Access Code." });
    }
  } else {
    squad = {
      name,
      accessCode,
      members: ["captain_1"],
      solves: 0,
      streakBonus: 20,
      score: 20,
      lastSnippet: ""
    };
    db.squads.push(squad);
  }

  res.json({ squads: db.squads });
});

app.post("/api/submissions", authMiddleware, (req, res) => {
  const { problemId, code, squadName, passed, points } = req.body;
  const user = req.user;

  if (passed && !user.solvedIds.includes(problemId)) {
    user.solvedIds.push(problemId);
    user.streak += 1;
    
    const squad = db.squads.find((s) => s.name === squadName);
    if (squad) {
      squad.solves += 1;
      squad.score += points || 100;
      squad.lastSnippet = code;
    }
  }

  db.submissions.push({
    userHandle: user.handle,
    problemId,
    passed,
    timestamp: new Date().toISOString()
  });

  const { passwordHash, ...userClean } = user;
  res.json({ user: userClean, squads: db.squads });
});

if (require.main === module) {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`CodeDojo Express API running on port ${PORT}`));
}

module.exports = { app, db, sessions };
